﻿namespace WordWork.Resource
{
    static class SettingsApp
    {
        public static string[] information = new string[20];// Массив, где будет хранится информация с главной формы
    }
}
