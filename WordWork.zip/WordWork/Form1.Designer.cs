﻿namespace WordWork
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb5 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.dtb1 = new System.Windows.Forms.DateTimePicker();
            this.tb18 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tb17 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tb16 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tb15 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tb14 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tb13 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tb12 = new System.Windows.Forms.TextBox();
            this.tb11 = new System.Windows.Forms.TextBox();
            this.tb10 = new System.Windows.Forms.TextBox();
            this.tb9 = new System.Windows.Forms.TextBox();
            this.tb8 = new System.Windows.Forms.TextBox();
            this.tb7 = new System.Windows.Forms.TextBox();
            this.tb6 = new System.Windows.Forms.TextBox();
            this.tb4 = new System.Windows.Forms.TextBox();
            this.tb3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tb1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.TroubleShab = new System.Windows.Forms.Label();
            this.tb19 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // tb5
            // 
            this.tb5.Location = new System.Drawing.Point(186, 63);
            this.tb5.Name = "tb5";
            this.tb5.Size = new System.Drawing.Size(268, 20);
            this.tb5.TabIndex = 60;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label19.Location = new System.Drawing.Point(190, 47);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(94, 13);
            this.label19.TabIndex = 59;
            this.label19.Text = "Сумма прописью";
            // 
            // dtb1
            // 
            this.dtb1.Location = new System.Drawing.Point(342, 20);
            this.dtb1.Name = "dtb1";
            this.dtb1.Size = new System.Drawing.Size(127, 20);
            this.dtb1.TabIndex = 58;
            this.dtb1.ValueChanged += new System.EventHandler(this.dtb1_ValueChanged);
            // 
            // tb18
            // 
            this.tb18.Location = new System.Drawing.Point(3, 570);
            this.tb18.Name = "tb18";
            this.tb18.Size = new System.Drawing.Size(534, 20);
            this.tb18.TabIndex = 57;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label18.Location = new System.Drawing.Point(6, 554);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(44, 13);
            this.label18.TabIndex = 56;
            this.label18.Text = "E-mail:  ";
            // 
            // tb17
            // 
            this.tb17.Location = new System.Drawing.Point(3, 531);
            this.tb17.Name = "tb17";
            this.tb17.Size = new System.Drawing.Size(534, 20);
            this.tb17.TabIndex = 55;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label17.Location = new System.Drawing.Point(6, 515);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 13);
            this.label17.TabIndex = 54;
            this.label17.Text = "Телефон:";
            // 
            // tb16
            // 
            this.tb16.Location = new System.Drawing.Point(3, 492);
            this.tb16.Name = "tb16";
            this.tb16.Size = new System.Drawing.Size(534, 20);
            this.tb16.TabIndex = 53;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(6, 476);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 13);
            this.label16.TabIndex = 52;
            this.label16.Text = "БИК";
            // 
            // tb15
            // 
            this.tb15.Location = new System.Drawing.Point(3, 453);
            this.tb15.Name = "tb15";
            this.tb15.Size = new System.Drawing.Size(534, 20);
            this.tb15.TabIndex = 51;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(6, 437);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(134, 13);
            this.label15.TabIndex = 50;
            this.label15.Text = "Корреспондентский счёт";
            // 
            // tb14
            // 
            this.tb14.Location = new System.Drawing.Point(2, 414);
            this.tb14.Name = "tb14";
            this.tb14.Size = new System.Drawing.Size(534, 20);
            this.tb14.TabIndex = 49;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(5, 398);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(117, 13);
            this.label14.TabIndex = 47;
            this.label14.Text = "Наименование Банка";
            // 
            // tb13
            // 
            this.tb13.Location = new System.Drawing.Point(2, 375);
            this.tb13.Name = "tb13";
            this.tb13.Size = new System.Drawing.Size(534, 20);
            this.tb13.TabIndex = 48;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label13.Location = new System.Drawing.Point(6, 359);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 13);
            this.label13.TabIndex = 46;
            this.label13.Text = "Расчетный счёт (р/с)";
            // 
            // tb12
            // 
            this.tb12.Location = new System.Drawing.Point(3, 336);
            this.tb12.Name = "tb12";
            this.tb12.Size = new System.Drawing.Size(534, 20);
            this.tb12.TabIndex = 44;
            // 
            // tb11
            // 
            this.tb11.Location = new System.Drawing.Point(4, 297);
            this.tb11.Name = "tb11";
            this.tb11.Size = new System.Drawing.Size(534, 20);
            this.tb11.TabIndex = 43;
            // 
            // tb10
            // 
            this.tb10.Location = new System.Drawing.Point(3, 260);
            this.tb10.Name = "tb10";
            this.tb10.Size = new System.Drawing.Size(534, 20);
            this.tb10.TabIndex = 42;
            // 
            // tb9
            // 
            this.tb9.Location = new System.Drawing.Point(3, 219);
            this.tb9.Name = "tb9";
            this.tb9.Size = new System.Drawing.Size(534, 20);
            this.tb9.TabIndex = 45;
            // 
            // tb8
            // 
            this.tb8.Location = new System.Drawing.Point(3, 180);
            this.tb8.Name = "tb8";
            this.tb8.Size = new System.Drawing.Size(534, 20);
            this.tb8.TabIndex = 41;
            // 
            // tb7
            // 
            this.tb7.Location = new System.Drawing.Point(3, 141);
            this.tb7.Name = "tb7";
            this.tb7.Size = new System.Drawing.Size(533, 20);
            this.tb7.TabIndex = 37;
            // 
            // tb6
            // 
            this.tb6.Location = new System.Drawing.Point(3, 102);
            this.tb6.Name = "tb6";
            this.tb6.Size = new System.Drawing.Size(534, 20);
            this.tb6.TabIndex = 40;
            // 
            // tb4
            // 
            this.tb4.Location = new System.Drawing.Point(4, 63);
            this.tb4.Name = "tb4";
            this.tb4.Size = new System.Drawing.Size(156, 20);
            this.tb4.TabIndex = 39;
            // 
            // tb3
            // 
            this.tb3.Location = new System.Drawing.Point(484, 20);
            this.tb3.Name = "tb3";
            this.tb3.Size = new System.Drawing.Size(521, 20);
            this.tb3.TabIndex = 38;
            this.tb3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb3_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(353, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 13);
            this.label3.TabIndex = 36;
            this.label3.Text = "Дата составления";
            // 
            // tb2
            // 
            this.tb2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb2.Location = new System.Drawing.Point(165, 20);
            this.tb2.Name = "tb2";
            this.tb2.Size = new System.Drawing.Size(157, 20);
            this.tb2.TabIndex = 35;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label12.Location = new System.Drawing.Point(6, 320);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "КПП";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(162, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 13);
            this.label2.TabIndex = 34;
            this.label2.Text = "Место составления Договора";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(7, 281);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 13);
            this.label11.TabIndex = 27;
            this.label11.Text = "ИНН";
            // 
            // tb1
            // 
            this.tb1.Location = new System.Drawing.Point(5, 20);
            this.tb1.Name = "tb1";
            this.tb1.Size = new System.Drawing.Size(137, 20);
            this.tb1.TabIndex = 33;
            this.tb1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(6, 242);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(36, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "ОГРН";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(7, 203);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(310, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "Фактический Адрес (место нахождения юридического лца)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(7, 164);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(363, 13);
            this.label8.TabIndex = 26;
            this.label8.Text = "Юридический адрес (место регистрации ИП или юридического лица)  ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(7, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(287, 13);
            this.label6.TabIndex = 31;
            this.label6.Text = "Адрес обьекта (там где будет осущевстляться услуга) ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(7, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(257, 13);
            this.label5.TabIndex = 28;
            this.label5.Text = "В лице ФИО (полностью) Иванов Иван Иванович";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(8, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(140, 13);
            this.label7.TabIndex = 29;
            this.label7.Text = "Стоимость услуг (100 000)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(481, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "Наименование юр. лица (ИП)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(29, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 32;
            this.label1.Text = "Номер Договора";
            // 
            // button3
            // 
            this.button3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button3.Location = new System.Drawing.Point(848, 587);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(157, 23);
            this.button3.TabIndex = 22;
            this.button3.Text = "Сформировать документ";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.createDoc_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(86, 596);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 61;
            this.button1.Text = "Шаблоны";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(167, 601);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(108, 13);
            this.label20.TabIndex = 62;
            this.label20.Text = "Выбрано шаблонов:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(277, 601);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 13);
            this.label21.TabIndex = 63;
            this.label21.Text = "label21";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(5, 596);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 64;
            this.button2.Text = "История";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // TroubleShab
            // 
            this.TroubleShab.AutoSize = true;
            this.TroubleShab.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TroubleShab.ForeColor = System.Drawing.Color.Red;
            this.TroubleShab.Location = new System.Drawing.Point(553, 63);
            this.TroubleShab.Name = "TroubleShab";
            this.TroubleShab.Size = new System.Drawing.Size(256, 25);
            this.TroubleShab.TabIndex = 65;
            this.TroubleShab.Text = "Проблема с шаблонами!!!";
            this.TroubleShab.Visible = false;
            // 
            // tb19
            // 
            this.tb19.Location = new System.Drawing.Point(457, 20);
            this.tb19.Name = "tb19";
            this.tb19.Size = new System.Drawing.Size(12, 20);
            this.tb19.TabIndex = 66;
            this.tb19.Visible = false;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(558, 105);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 485);
            this.listBox1.TabIndex = 67;
            this.listBox1.Visible = false;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1014, 625);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.tb19);
            this.Controls.Add(this.TroubleShab);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tb5);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.dtb1);
            this.Controls.Add(this.tb18);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.tb17);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.tb16);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.tb15);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.tb14);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.tb13);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.tb12);
            this.Controls.Add(this.tb11);
            this.Controls.Add(this.tb10);
            this.Controls.Add(this.tb9);
            this.Controls.Add(this.tb8);
            this.Controls.Add(this.tb7);
            this.Controls.Add(this.tb6);
            this.Controls.Add(this.tb4);
            this.Controls.Add(this.tb3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.tb1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DateTimePicker dtb1;
        private System.Windows.Forms.TextBox tb18;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tb17;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tb16;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tb15;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tb14;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tb13;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tb12;
        private System.Windows.Forms.TextBox tb11;
        private System.Windows.Forms.TextBox tb10;
        private System.Windows.Forms.TextBox tb9;
        private System.Windows.Forms.TextBox tb8;
        private System.Windows.Forms.TextBox tb7;
        private System.Windows.Forms.TextBox tb6;
        private System.Windows.Forms.TextBox tb4;
        private System.Windows.Forms.TextBox tb3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tb1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label TroubleShab;
        private System.Windows.Forms.TextBox tb19;
        private System.Windows.Forms.ListBox listBox1;
    }
}

